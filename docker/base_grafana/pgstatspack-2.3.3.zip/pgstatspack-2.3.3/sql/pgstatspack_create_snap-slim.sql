SET client_min_messages TO error;
-- Create pgstatspack_snap procedure.
--
-- By frits.hoogland@interaccess.nl
-- Based on Glenn.Fawcett@Sun.com's snap procedure
-- meo.bogliolo@xenialab.it added pgstatspack_activity table
-- meo.bogliolo@xenialab.it changed pg_stat_activity structure,
--                          added 9.6 support, reduced pg_stat_statements query length (up to 512)
-- meo.bogliolo@xenialab.it short version: summarizzed tables, indexes; excluded settings, statements

CREATE OR REPLACE FUNCTION pgstatspack_snap ( description varchar(256) ) RETURNS bigint AS $$
DECLARE
  now_dts TIMESTAMP;
  spid BIGINT;
  version_major int;
  version_minor int;
BEGIN
SELECT current_timestamp INTO now_dts; 
  SELECT nextval('pgstatspackid') INTO spid;
  INSERT INTO pgstatspack_snap values (spid, now_dts, description);

insert into pgstatspack_names (name)
select distinct datname
from pg_database
left join pgstatspack_names on datname=name
where
 name is null;

INSERT INTO pgstatspack_database
(snapid, datid, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, dbnameid)
SELECT
  spid               as snapid,
  d.datid            as datid,
  d.numbackends     as numbackends,
  d.xact_commit         as xact_commit,
  d.xact_rollback    as xact_rollback,
  d.blks_read        as blks_read,
  d.blks_hit        as blks_hit,
  n.nameid
FROM
  pg_stat_database d
JOIN pgstatspack_names n on d.datname=n.name;


INSERT INTO pgstatspack_tables
( snapid, seq_scan, seq_tup_read, idx_scan, idx_tup_fetch, n_tup_ins, 
  n_tup_upd, n_tup_del, heap_blks_read, heap_blks_hit, idx_blks_read, 
  idx_blks_hit, toast_blks_read, toast_blks_hit, tidx_blks_read, 
  tidx_blks_hit, tbl_size, idx_size, table_name_id)
SELECT
  spid               as snapid,
  sum(t.seq_scan)        as seq_scan,
  sum(t.seq_tup_read)    as seq_tup_read,
  sum(t.idx_scan)        as idx_scan,
  sum(t.idx_tup_fetch)   as idx_tup_fetch,
  sum(t.n_tup_ins)       as n_tup_ins,
  sum(t.n_tup_upd)       as n_tup_upd,
  sum(t.n_tup_del)       as n_tup_del,
  sum(it.heap_blks_read) as heap_blks_read,
  sum(it.heap_blks_hit)  as heap_blks_hit,
  sum(it.idx_blks_read)  as idx_blks_read,
  sum(it.idx_blks_hit)   as idx_blks_hit,
  sum(it.toast_blks_read) as toast_blks_read,
  sum(it.toast_blks_hit) as toast_blks_hit,
  sum(it.tidx_blks_read) as tidx_blks_read,
  sum(it.tidx_blks_hit)   as tidx_blks_hit,
  sum(pg_relation_size(t.relid)+pg_relation_size(s.relid)) as tbl_size,
  sum(pg_relation_size(i.indexrelid)) as idx_size,
  0
FROM
  pg_statio_all_tables it,
  pg_stat_all_tables t
  JOIN pg_class c on t.relid=c.oid
  LEFT JOIN pg_stat_sys_tables s on c.reltoastrelid=s.relid 
  LEFT JOIN pg_index i on i.indrelid=t.relid
  LEFT JOIN pg_locks l on c.oid=l.relation and locktype='relation' and mode in ('AccessExclusiveLock','ShareRowExclusiveLock','ShareLock','ShareUpdateExclusiveLock')
WHERE
  l.relation is null and
  (t.relid = it.relid);

INSERT INTO pgstatspack_indexes
( snapid, idx_scan, idx_tup_read, idx_tup_fetch, idx_blks_read, 
  idx_blks_hit, index_name_id, table_name_id)
SELECT
  spid                   as snapid,
  sum(i.idx_scan)        as idx_scan,
  sum(i.idx_tup_read)    as idx_tup_read,
  sum(i.idx_tup_fetch)   as idx_tup_fetch,
  sum(ii.idx_blks_read)  as idx_blks_read,
  sum(ii.idx_blks_hit)   as idx_blks_hit,
  0,
  0
FROM
  pg_stat_all_indexes i
  join pg_statio_all_indexes ii on i.indexrelid = ii.indexrelid;

select cast(substring(version(), 'PostgreSQL ([0-9]*).') as int) into version_major;
select cast(substring(version(), 'PostgreSQL [0-9]*.([0-9]*).') as int) into version_minor;

IF ((version_major = 8 AND version_minor >= 4 ) OR version_major > 8 ) THEN
 BEGIN
  insert into pgstatspack_names (name)
  select schemaname||'.'||funcname
  from pg_stat_user_functions
  left join pgstatspack_names on schemaname||'.'||funcname=name
  where
   name is null;

  insert into pgstatspack_functions
  ( snapid, funcid, calls, total_time, self_time, function_name_id)
   select
   spid as snapid,
   funcid as funcid,
   calls as calls,
   total_time as total_time,
   self_time as self_time,
   n.nameid
  from
   pg_stat_user_functions
   join pgstatspack_names n on schemaname||'.'||funcname=n.name
  order by total_time
  limit 100;
 END;
END IF;

IF ((version_major = 8 AND version_minor >= 3 ) OR version_major > 8 ) THEN
	insert into pgstatspack_bgwriter select
	spid as snapid,
	checkpoints_timed,
	checkpoints_req,
	buffers_checkpoint,
	buffers_clean,
	maxwritten_clean,
	buffers_backend,
	buffers_alloc
	from pg_stat_bgwriter;
END IF;

insert into pgstatspack_names (name)
 select distinct coalesce(usename, 'NONE')
 from pg_stat_activity
 left join pgstatspack_names on coalesce(usename, 'NONE')=name
 where
  datid=(select oid from pg_database where datname=current_database()) and
  name is null;

insert into pgstatspack_names (name)
 select distinct coalesce(application_name, 'NONE')
 from pg_stat_activity
 left join pgstatspack_names on coalesce(application_name, 'NONE')=name
 where
  datid=(select oid from pg_database where datname=current_database()) and
  name is null;

IF ((version_major = 9 AND version_minor >= 6 ) OR version_major > 9 ) THEN
INSERT INTO pgstatspack_activity
    (snapid, count_star, user_name_id, application_name_id, client_addr, waiting, working)
    SELECT
      spid,
      count(*),
      n1.nameid,
      n2.nameid,
      coalesce(a.client_addr,'0.0.0.0/0'),
      a.wait_event is not null,
      coalesce(a.state='active', 'false')
    FROM pg_stat_activity a
    left join pgstatspack_names n1 on coalesce(a.usename, 'NONE')=n1.name
    join pgstatspack_names n2 on coalesce(a.application_name, 'NONE')=n2.name
    WHERE datid=(select oid from pg_database where datname=current_database())
    GROUP BY spid, n1.nameid, n2.nameid, coalesce(a.client_addr,'0.0.0.0/0'), a.wait_event is not null, coalesce(a.state='active', 'false');
ELSE
IF (version_major = 9 AND version_minor >= 2 ) THEN
INSERT INTO pgstatspack_activity
    (snapid, count_star, user_name_id, application_name_id, client_addr, waiting, working)
    SELECT
      spid,
      count(*),
      n1.nameid,
      n2.nameid,
      coalesce(a.client_addr,'0.0.0.0/0'),
      a.waiting,
      coalesce(a.state='active', 'false')
    FROM pg_stat_activity a
    left join pgstatspack_names n1 on coalesce(a.usename, 'NONE')=n1.name
    join pgstatspack_names n2 on coalesce(a.application_name, 'NONE')=n2.name
    WHERE datid=(select oid from pg_database where datname=current_database())
    GROUP BY spid, n1.nameid, n2.nameid, coalesce(a.client_addr,'0.0.0.0/0'), a.waiting, coalesce(a.state='active', 'false');
ELSE
INSERT INTO pgstatspack_activity
    (snapid, count_star, user_name_id, application_name_id, client_addr, waiting, working)
    SELECT
      spid,
      count(*),
      n1.nameid,
      n2.nameid,
      coalesce(a.client_addr,'0.0.0.0/0'),
      a.waiting,
      case when a.current_query='<IDLE>' then false else true end
    FROM pg_stat_activity a
    left join pgstatspack_names n1 on coalesce(a.usename, 'NONE')=n1.name
    join pgstatspack_names n2 on coalesce(a.application_name, 'NONE')=n2.name
    WHERE datid=(select oid from pg_database where datname=current_database())
    GROUP BY spid, n1.nameid, n2.nameid, coalesce(a.client_addr,'0.0.0.0/0'), a.waiting, case when a.current_query='<IDLE>' then false else true end;
 END IF;
END IF;

RETURN spid;
END;
$$ LANGUAGE plpgsql;

