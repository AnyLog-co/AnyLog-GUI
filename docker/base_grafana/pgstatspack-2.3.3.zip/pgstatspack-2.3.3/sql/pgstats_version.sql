select max(version) from pgstatspack_version;
